let balance = deposit(); //what ever the user types for deposit it will be sotred at balance
// const numberOfLines = getNumberLinesOfLines();
// const bet = getBet(balance, numberOfLines);